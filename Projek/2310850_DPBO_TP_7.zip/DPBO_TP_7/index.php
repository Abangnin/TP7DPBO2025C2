<?php
header('Location: view/drinks/list.php');
exit;
?>