<?php
include '../../config/connection.php';
include '../../class/Supplier.php';

$supplier = new Supplier($pdo);
$data = $supplier->getAll();
?>

<style>
    body {
        font-family: Arial, sans-serif;
        background-color: #f5f5f5;
        margin: 0;
        padding: 20px;
    }

    h2 {
        text-align: center;
        margin-bottom: 20px;
    }

    a {
        text-decoration: none;
        color: #007bff;
        font-weight: bold;
    }

    a:hover {
        text-decoration: underline;
    }

    .add-link {
        display: inline-block;
        margin-bottom: 10px;
        background-color: #28a745;
        color: white;
        padding: 8px 12px;
        border-radius: 5px;
    }

    .back-link {
        display: block;
        margin-top: 20px;
        text-align: center;
        color: #007bff;
    }

    table {
        width: 100%;
        border-collapse: collapse;
        background-color: white;
        margin: auto;
        max-width: 800px;
        border-radius: 8px;
        overflow: hidden;
        box-shadow: 0 0 8px rgba(0,0,0,0.1);
    }

    th, td {
        padding: 12px 15px;
        text-align: left;
        border-bottom: 1px solid #ddd;
    }

    th {
        background-color: #007bff;
        color: white;
    }

    tr:hover {
        background-color: #f1f1f1;
    }

    .action-links a {
        margin-right: 10px;
        color: #007bff;
    }

    .action-links a:hover {
        text-decoration: underline;
    }
</style>

<h2>Daftar Supplier</h2>

<a class="add-link" href="add.php">+ Tambah Supplier</a>

<table>
    <tr>
        <th>ID</th>
        <th>Nama Supplier</th>
        <th>Kontak Alamat</th>
        <th>Aksi</th>
    </tr>
    <?php foreach ($data as $row) { ?>
    <tr>
        <td><?= $row['supplier_id'] ?></td>
        <td><?= $row['supplier_name'] ?></td>
        <td><?= $row['contact_info'] ?></td>
        <td class="action-links">
            <a href="edit.php?id=<?= $row['supplier_id'] ?>">Edit</a>
            <a href="delete.php?id=<?= $row['supplier_id'] ?>" onclick="return confirm('Yakin ingin menghapus?')">Hapus</a>
        </td>
    </tr>
    <?php } ?>
</table>

<a class="back-link" href="../drinks/list.php">Kembali ke daftar</a>
