<?php
include '../../config/connection.php';
include '../../class/Supplier.php';

$supplier = new Supplier($pdo);
$supplier->delete($_GET['id']);
header("Location: list.php");
