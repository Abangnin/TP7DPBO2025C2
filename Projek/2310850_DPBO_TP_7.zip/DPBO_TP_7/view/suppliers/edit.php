<?php
include '../../config/connection.php';
include '../../class/Supplier.php';

$supplier = new Supplier($pdo);
$id = $_GET['id'];
$data = $supplier->getById($id);

if (isset($_POST['submit'])) {
    $supplier->update($id, $_POST['supplier_name'], $_POST['contact_info']);
    header("Location: list.php");
}
?>

<style>
    body {
        font-family: Arial, sans-serif;
        background-color: #f5f5f5;
        margin: 0;
        padding: 0;
    }

    h2 {
        text-align: center;
        padding: 20px 0 10px;
        margin: 0;
    }

    form {
        background-color: #fff;
        width: 400px;
        margin: 20px auto;
        padding: 20px 30px;
        border: 1px solid #ccc;
        border-radius: 10px;
    }

    form input[type="text"],
    form input[type="number"],
    form select {
        width: 100%;
        padding: 8px;
        margin-top: 5px;
        margin-bottom: 15px;
        border: 1px solid #aaa;
        border-radius: 5px;
        box-sizing: border-box;
    }

    form button {
        width: 100%;
        padding: 10px;
        background-color: #28a745;
        color: white;
        border: none;
        border-radius: 5px;
        cursor: pointer;
        font-weight: bold;
    }

    form button:hover {
        background-color: #218838;
    }

    .back-link {
        display: block;
        text-align: center;
        margin-top: 15px;
        text-decoration: none;
        color: #007bff;
        font-weight: bold;
    }

    .back-link:hover {
        text-decoration: underline;
    }
</style>

<h2>Edit Supplier</h2>
<form method="post">
    <label>Nama Supplier:</label>
    <input type="text" name="supplier_name" value="<?= $data['supplier_name'] ?>" required>

    <label>Kontak Alamat:</label>
    <input type="text" name="contact_info" value="<?= $data['contact_info'] ?>" required>

    <input type="submit" name="submit" value="Update">
</form>
<a class="back-link" href="list.php">Kembali ke daftar</a>