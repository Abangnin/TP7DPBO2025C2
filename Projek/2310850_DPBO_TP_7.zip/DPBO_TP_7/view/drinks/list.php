<?php
require_once '../../config/connection.php';
require_once '../../class/Drink.php';

$drinkObj = new Drink($pdo);
$search = $_GET['search'] ?? '';
$drinks = $drinkObj->getAll($search);
?>

<style>
    body {
        font-family: Arial, sans-serif;
        background-color: #f5f5f5;
        margin: 0;
        padding: 0;
    }

    h2 {
        text-align: center;
        padding: 20px 0 10px;
        margin: 0;
    }

    .nav-links {
        text-align: center;
        margin-bottom: 15px;
    }

    .nav-links a {
        margin: 0 10px;
        text-decoration: none;
        color: #0055aa;
        font-weight: bold;
    }

    form {
        text-align: center;
        margin-bottom: 20px;
    }

    table {
        border-collapse: collapse;
        width: 90%;
        margin: auto;
        background-color: #ffffff;
        border: 1px solid #ccc;
    }

    th, td {
        border: 1px solid #ccc;
        padding: 10px;
        text-align: center;
    }

    th {
        background-color: #e0e0e0;
        font-weight: bold;
    }

    tr:nth-child(even),
    tr:nth-child(odd) {
        background-color: #ffffff;
    }

    .footer {
        text-align: center;
        margin-top: 30px;
        font-size: 0.8em;
        color: #555;
        padding-bottom: 15px;
    }
</style>

<h2>Daftar Minuman - Minuman Berclasss</h2>

<div class="nav-links">
    <a href="add.php">Tambah Minuman</a> |
    <a href="../categorys/list.php">Tambah Kategori</a> |
    <a href="../suppliers/list.php">Tambah Supplier</a>
</div>

<form method="get" action="">
    <input type="text" name="search" placeholder="Cari minuman...">
    <input type="submit" value="Cari">
</form>

<table>
    <tr>
        <th>Nama</th>
        <th>Harga</th>
        <th>Kategori</th>
        <th>Supplier</th>
        <th>Aksi</th>
    </tr>

    <?php if (!empty($drinks)): ?>
        <?php foreach ($drinks as $drink): ?>
            <tr>
                <td><?= htmlspecialchars($drink['name']) ?></td>
                <td><?= htmlspecialchars($drink['price']) ?></td>
                <td><?= htmlspecialchars($drink['category_name']) ?></td>
                <td><?= htmlspecialchars($drink['supplier_name']) ?></td>
                <td>
                    <a href="edit.php?id=<?= $drink['drink_id'] ?>">Edit</a> |
                    <a href="delete.php?id=<?= $drink['drink_id'] ?>" onclick="return confirm('Hapus data ini?')">Hapus</a>
                </td>
            </tr>
        <?php endforeach; ?>
    <?php else: ?>
        <tr>
            <td colspan="5">Tidak ada data minuman.</td>
        </tr>
    <?php endif; ?>
</table>