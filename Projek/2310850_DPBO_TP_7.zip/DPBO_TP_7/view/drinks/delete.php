<?php
require_once '../../config/connection.php';

$id = $_GET['id'] ?? null;
if ($id) {
    $stmt = $pdo->prepare("DELETE FROM drinks WHERE drink_id = :id");
    $stmt->execute(['id' => $id]);
}

header("Location: list.php");
exit;
