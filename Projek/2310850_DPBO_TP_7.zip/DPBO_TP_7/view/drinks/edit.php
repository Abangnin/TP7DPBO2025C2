<?php
require_once '../../config/connection.php';
require_once '../../class/Category.php';
require_once '../../class/Supplier.php';

$categoryObj = new Category($pdo);
$supplierObj = new Supplier($pdo);
$categories = $categoryObj->getAll();
$suppliers = $supplierObj->getAll();

$id = $_GET['id'] ?? null;
if (!$id) {
    header("Location: list.php");
    exit;
}

// Ambil data minuman
$stmt = $pdo->prepare("SELECT * FROM drinks WHERE drink_id = :id");
$stmt->execute(['id' => $id]);
$drink = $stmt->fetch();

if (!$drink) {
    echo "Data tidak ditemukan.";
    exit;
}

// Simpan perubahan
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'];
    $price = $_POST['price'];
    $category_id = $_POST['category_id'];
    $supplier_id = $_POST['supplier_id'];

    $stmt = $pdo->prepare("UPDATE drinks 
        SET name = :name, price = :price, category_id = :category_id, supplier_id = :supplier_id 
        WHERE drink_id = :id");
    $stmt->execute([
        'name' => $name,
        'price' => $price,
        'category_id' => $category_id,
        'supplier_id' => $supplier_id,
        'id' => $id
    ]);

    header("Location: list.php");
    exit;
}
?>

<!-- Tempelkan di atas tag <h2> -->
<style>
    body {
        font-family: Arial, sans-serif;
        background-color: #f5f5f5;
        margin: 0;
        padding: 0;
    }

    h2 {
        text-align: center;
        padding: 20px 0 10px;
        margin: 0;
    }

    form {
        background-color: #fff;
        width: 400px;
        margin: 20px auto;
        padding: 20px 30px;
        border: 1px solid #ccc;
        border-radius: 10px;
    }

    form input[type="text"],
    form input[type="number"],
    form select {
        width: 100%;
        padding: 8px;
        margin-top: 5px;
        margin-bottom: 15px;
        border: 1px solid #aaa;
        border-radius: 5px;
        box-sizing: border-box;
    }

    form button {
        width: 100%;
        padding: 10px;
        background-color: #28a745;
        color: white;
        border: none;
        border-radius: 5px;
        cursor: pointer;
        font-weight: bold;
    }

    form button:hover {
        background-color: #218838;
    }

    .back-link {
        display: block;
        text-align: center;
        margin-top: 15px;
        text-decoration: none;
        color: #007bff;
        font-weight: bold;
    }

    .back-link:hover {
        text-decoration: underline;
    }
</style>


<h2>Edit Minuman</h2>

<form method="POST">
    <label>Nama Minuman:</label><br>
    <input type="text" name="name" value="<?= htmlspecialchars($drink['name']) ?>" required><br><br>

    <label>Harga:</label><br>
    <input type="number" step="0.01" name="price" value="<?= $drink['price'] ?>" required><br><br>

    <label>Kategori:</label><br>
    <select name="category_id" required>
        <?php foreach ($categories as $cat): ?>
            <option value="<?= $cat['category_id'] ?>" <?= $cat['category_id'] == $drink['category_id'] ? 'selected' : '' ?>>
                <?= htmlspecialchars($cat['category_name']) ?>
            </option>
        <?php endforeach; ?>
    </select><br><br>

    <label>Supplier:</label><br>
    <select name="supplier_id" required>
        <?php foreach ($suppliers as $sup): ?>
            <option value="<?= $sup['supplier_id'] ?>" <?= $sup['supplier_id'] == $drink['supplier_id'] ? 'selected' : '' ?>>
                <?= htmlspecialchars($sup['supplier_name']) ?>
            </option>
        <?php endforeach; ?>
    </select><br><br>

    <button type="submit">Simpan Perubahan</button>
</form>

<a class="back-link" href="list.php">Kembali ke daftar</a>
