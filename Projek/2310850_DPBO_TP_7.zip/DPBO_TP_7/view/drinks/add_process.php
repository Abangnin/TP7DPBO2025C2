<?php
include '../../config/connection.php';
include '../../class/Drink.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $drink_name = $_POST['name'];
    $price = $_POST['price'];
    $category_id = $_POST['category_id'];
    $supplier_id = $_POST['supplier_id'];

    if (!empty($drink_name) && !empty($price) && !empty($category_id) && !empty($supplier_id)) {
        $drink = new Drink($pdo);
        $drink->add($drink_name, $price, $category_id, $supplier_id);
        header("Location: list.php");
        exit();
    } else {
        echo "Harap isi semua kolom.";
    }
}
?>
