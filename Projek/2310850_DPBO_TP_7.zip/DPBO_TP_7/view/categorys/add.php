<?php
include '../../config/connection.php';
include '../../class/Category.php';

if (isset($_POST['submit'])) {
    $category = new Category($pdo);
    $category->add($_POST['category_name']);
    header("Location: list.php");
}
?>

<style>
    body {
        font-family: Arial, sans-serif;
        background-color: #f5f5f5;
        margin: 0;
        padding: 0;
    }

    h2 {
        text-align: center;
        padding: 20px 0 10px;
        margin: 0;
    }

    form {
        background-color: #fff;
        width: 400px;
        margin: 20px auto;
        padding: 20px 30px;
        border: 1px solid #ccc;
        border-radius: 10px;
    }

    form input[type="text"],
    form input[type="number"],
    form select {
        width: 100%;
        padding: 8px;
        margin-top: 5px;
        margin-bottom: 15px;
        border: 1px solid #aaa;
        border-radius: 5px;
        box-sizing: border-box;
    }

    form input[type="submit"] {
        width: 100%;
        padding: 10px;
        background-color: #007bff;
        color: white;
        border: none;
        border-radius: 5px;
        cursor: pointer;
        font-weight: bold;
    }

    form input[type="submit"]:hover {
        background-color: #0056b3;
    }

    .back-link {
        display: block;
        text-align: center;
        margin-top: 15px;
        text-decoration: none;
        color: #007bff;
        font-weight: bold;
    }

    .back-link:hover {
        text-decoration: underline;
    }
</style>

<h2>Tambah Kategori</h2>
<form method="post">
    <label>Nama Kategori:</label>
    <input type="text" name="category_name" required>
    <input type="submit" name="submit" value="Simpan">
</form>

<a class="back-link" href="list.php">Kembali ke daftar</a>