<?php
include '../../config/connection.php';
include '../../class/Category.php';

$category = new Category($pdo);
$category->delete($_GET['id']);
header("Location: list.php");
