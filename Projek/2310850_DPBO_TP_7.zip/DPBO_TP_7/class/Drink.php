<?php
class Drink {
    private $pdo;

    public function __construct($pdo) {
        $this->pdo = $pdo;
    }

    public function getAll($search = '') {
        $query = "SELECT d.*, c.category_name, s.supplier_name
                  FROM drinks d
                  LEFT JOIN drink_categories c ON d.category_id = c.category_id
                  LEFT JOIN suppliers s ON d.supplier_id = s.supplier_id
                  WHERE d.name LIKE :search";
        $stmt = $this->pdo->prepare($query);
        $stmt->execute(['search' => "%$search%"]);
        return $stmt->fetchAll();
    }
    
    public function add($name, $price, $category_id, $supplier_id) {
        $stmt = $this->pdo->prepare("INSERT INTO drinks (name, price, category_id, supplier_id) VALUES (?, ?, ?, ?)");
        return $stmt->execute([$name, $price, $category_id, $supplier_id]);
    }
    
}
?>
