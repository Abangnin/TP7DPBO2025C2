<?php
class Supplier {
    private $pdo;

    public function __construct($pdo) {
        $this->pdo = $pdo;
    }

    public function getAll() {
        $stmt = $this->pdo->query("SELECT * FROM suppliers");
        return $stmt->fetchAll();
    }

    public function getById($id) {
        $stmt = $this->pdo->prepare("SELECT * FROM suppliers WHERE supplier_id = ?");
        $stmt->execute([$id]);
        return $stmt->fetch();
    }

    public function add($name, $contact) {
        $stmt = $this->pdo->prepare("INSERT INTO suppliers (supplier_name, contact_info) VALUES (?, ?)");
        return $stmt->execute([$name, $contact]);
    }

    public function update($id, $name, $contact) {
        $stmt = $this->pdo->prepare("UPDATE suppliers SET supplier_name = ?, contact_info = ? WHERE supplier_id = ?");
        return $stmt->execute([$name, $contact, $id]);
    }

    public function delete($id) {
        $stmt = $this->pdo->prepare("DELETE FROM suppliers WHERE supplier_id = ?");
        return $stmt->execute([$id]);
    }
}
?>
